# Time-Aut

**Visual Timer (not only) for Kids**

- Currently with T-Rex
- Easy to modify
- With acustic signal
- Visual feedback through movement and colors
- The amount of the dinosaurs corresponds to the amount of the lasting minutes
- The green-yellow-red bar is divided in golden ratio for better visual perception
- Low stimulus UI

This Timer is heavily inspirated by "Visual Timer" from "Aspie Apps" by "NORRBLICK" (www.aspieapps.com)

![time-aut.png](https://raw.githubusercontent.com/mounta11n/time-aut/main/time-aut.png)
